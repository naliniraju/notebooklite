# NotebookLite (Android)

Jupyter notebook viewer/editor with in-browser Python (Pyodide), search, and save/share.

## Easiest: build the APK from your phone (GitHub Actions)
1. Create a free GitHub repo and upload everything in this folder (keep the `.github` folder).
2. Open the repo's **Actions** tab, pick **Build APK**, tap **Run workflow**.
3. When it finishes (about 5 min), open the run and download the **NotebookLite-debug-apk** artifact.
4. Unzip it, open `app-debug.apk`, and allow "install unknown apps" when asked.

## Build on a computer
Needs Node 18+, JDK 17, Android Studio (SDK).
    npm install
    npm run vendor
    npx cap add android
    npx cap sync android
    cd android && ./gradlew assembleDebug
APK: android/app/build/outputs/apk/debug/app-debug.apk
(or `npx cap open android` and press Run).

## Use as a web app instead
Host the `www/` folder on GitHub Pages or any static host and open it in Chrome; Add to Home screen.

## Notes
- Python runs in WebView via Pyodide, loaded from jsDelivr on first run (internet needed; pure Python and
  packages like numpy, pandas, matplotlib load on demand). Viewing/editing/searching works offline.
- `!pip install x` / `%pip install x` use micropip (pure-Python wheels only).
- Execution can't be interrupted; a very long loop needs an app restart.
- Debug APK only. For Play Store, sign a release build.
