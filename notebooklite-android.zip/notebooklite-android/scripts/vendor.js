// Copies offline copies of marked + DOMPurify into www/vendor
const fs = require('fs');
fs.mkdirSync('www/vendor', { recursive: true });
fs.copyFileSync('node_modules/marked/marked.min.js', 'www/vendor/marked.min.js');
fs.copyFileSync('node_modules/dompurify/dist/purify.min.js', 'www/vendor/purify.min.js');
console.log('vendor files copied');
